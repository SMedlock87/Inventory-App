package com.example.medlockinventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class AddActivity extends AppCompatActivity {
    EditText itemID;
    EditText itemName;
    EditText category;
    EditText quantity;
    Button addItem;
    Button home;
    InventoryDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        db = new InventoryDatabase(this);
        itemID = (EditText) findViewById(R.id.edit_itemID);
        itemName = (EditText) findViewById(R.id.edit_itemName);
        category = (EditText) findViewById(R.id.edit_category);
        quantity = (EditText) findViewById(R.id.edit_quantity);
        addItem = (Button) findViewById(R.id.addItem);
        home = (Button) findViewById(R.id.inventory);
        addItem.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent addItemIntent = new Intent(AddActivity.this, InventoryActivity.class);
                startActivity(addItemIntent);
                String idInput = itemID.getText().toString().trim();
                String itemNameInput = itemName.getText().toString().trim();
                String categoryInput = category.getText().toString().trim();
                String quantityInput = quantity.getText().toString().trim();

                long res = db.checkItem(idInput, itemNameInput, categoryInput, quantityInput);
                Toast.makeText(AddActivity.this, "New Item Added", Toast.LENGTH_LONG).show();
            }


        });
        home.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent addItemIntent = new Intent(AddActivity.this, InventoryActivity.class);
                startActivity(addItemIntent);
            }
        });


    }
}