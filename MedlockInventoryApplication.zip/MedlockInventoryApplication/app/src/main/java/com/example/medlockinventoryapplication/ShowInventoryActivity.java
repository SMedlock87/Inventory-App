package com.example.medlockinventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;

public class ShowInventoryActivity extends AppCompatActivity {
    Button inventoryHome;
    GridView inventory;
    InventoryDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_inventory);


        inventory = (GridView) findViewById(R.id.showAllInventory);
        inventoryHome = (Button) findViewById(R.id.home_button);
        inventoryHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent HomeIntent = new Intent(ShowInventoryActivity.this, InventoryActivity.class);
                startActivity(HomeIntent);
            }
        });
    }
}
