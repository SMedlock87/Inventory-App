package com.example.medlockinventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class InventoryActivity extends AppCompatActivity {
    FloatingActionButton notifications;
    Button showInventory;
    Button addButton;
    Button updateButton;
    Button deleteButton;
    Button logOutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        notifications = (FloatingActionButton) findViewById(R.id.actionButtonNotifications);
        showInventory = (Button) findViewById(R.id.showAllButton);
        addButton = (Button) findViewById(R.id.addButton);
        updateButton = (Button) findViewById(R.id.updateButton);
        deleteButton = (Button) findViewById(R.id.deleteButton);
        logOutButton = (Button) findViewById(R.id.logOutButton);
        notifications.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent notificationsIntent = new Intent(InventoryActivity.this, NotificationsActivity.class);
                startActivity(notificationsIntent);
            }
        });
        showInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logOutIntent = new Intent(InventoryActivity.this, ShowInventoryActivity.class);
                startActivity(logOutIntent);
            }
        });
        logOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logOutIntent = new Intent(InventoryActivity.this, LoginActivity.class);
                startActivity(logOutIntent);
            }
        });
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logOutIntent = new Intent(InventoryActivity.this, AddActivity.class);
                startActivity(logOutIntent);
            }
        });
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logOutIntent = new Intent(InventoryActivity.this, DeleteActivity.class);
                startActivity(logOutIntent);
            }
        });
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logOutIntent = new Intent(InventoryActivity.this, UpdateActivity.class);
                startActivity(logOutIntent);
            }
        });
    }
}