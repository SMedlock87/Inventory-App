package com.example.medlockinventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    EditText usernameText;
    EditText passwordText;
    Button loginButton;
    TextView signUpText;
    SignUpDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new SignUpDatabase(this);
        usernameText = (EditText)findViewById(R.id.edit_username);
        passwordText = (EditText)findViewById(R.id.edit_password);
        loginButton = (Button) findViewById(R.id.login_button);
        signUpText =(TextView) findViewById(R.id.sign_up);
        loginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent LogInIntent = new Intent(LoginActivity.this, InventoryActivity.class);
                startActivity(LogInIntent);

                String usernameInput = usernameText.getText().toString().trim();
                String passwordInput = passwordText.getText().toString().trim();
                Boolean res = db.checkUser(usernameInput, passwordInput);
                if (res == false) {
                    Toast.makeText(LoginActivity.this, "Welcome to Medlock Inventory Application", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(LoginActivity.this, "Please Try Again!", Toast.LENGTH_LONG).show();
                }

            }
        });

        signUpText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent signUpIntent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(signUpIntent);

            }
            });
    }
}