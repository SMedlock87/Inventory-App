package com.example.medlockinventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity {
    EditText usernameText;
    EditText passwordText;
    EditText confirmPassword;
    Button RegisterButton;
    TextView signInText;
    SignUpDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        db = new SignUpDatabase(this);
        usernameText = (EditText) findViewById(R.id.edit_username);
        passwordText = (EditText) findViewById(R.id.edit_password);
        confirmPassword = (EditText) findViewById(R.id.confirmPassword);
        RegisterButton = (Button) findViewById(R.id.register);
        signInText = (TextView) findViewById(R.id.sign_in);
        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent signUpIntent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(signUpIntent);
            }
        });
        signInText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent signUpIntent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(signUpIntent);

                RegisterButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String user = usernameText.getText().toString().trim();
                        String password = passwordText.getText().toString().trim();
                        String confPass = confirmPassword.getText().toString().trim();

                        if (password.equals(confPass)) {
                            long value = db.addUser(user, password);
                            if (value > 0) {
                                Toast.makeText(SignUpActivity.this, "Sign Up Complete!", Toast.LENGTH_SHORT).show();
                                Intent switchToLogin = new Intent(SignUpActivity.this, LoginActivity.class);
                                startActivity(switchToLogin);
                            } else {
                                Toast.makeText(SignUpActivity.this, "Try again!", Toast.LENGTH_SHORT).show();
                            }

                        } else {
                            Toast.makeText(SignUpActivity.this, "Passwords do not match!", Toast.LENGTH_SHORT).show();
                        }
                    }

                });
            }
        });
    }
}