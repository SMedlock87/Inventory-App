package com.example.medlockinventoryapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.service.autofill.AutofillService;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "inventory.db";
    public static final String TABLE_NAME = "inventory";
    public static final String COL1_ID = "ID.db";
    public static final String COL2_NAME = "name.db";
    public static final String COL3_CATEGORY = "category.db";
    public static final String COL4_QUANTITY = "quantity.db";

    public InventoryDatabase(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE signUpUser (ID INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, category TEXT, quantity TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    public long checkItem(String ID, String name, String category, String quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ID", 0);
        contentValues.put("Name", name);
        contentValues.put("Category", category);
        contentValues.put("Quantity", quantity);
        long res = db.insert("inventory", null, contentValues);
        db.close();
        return res;

    }

    public boolean deleteItem(String name) {
        String columns = (COL1_ID);
        SQLiteDatabase db = getReadableDatabase();
        String selection = COL2_NAME + "=?" + "and" + COL3_CATEGORY;
        String[] selectionArg = {name};
        Cursor cursor = db.query(TABLE_NAME, new String[]{columns}, selection, selectionArg, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }

    public long updateItem(int ID, String name, String category, String quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ID", 0);
        contentValues.put("Name", name);
        contentValues.put("Category", category);
        contentValues.put("Quantity", quantity);
        long res = db.update("inventory", null, String.valueOf(contentValues), null);
        db.close();
        return res;


    }

    public long showAllInventory(int ID, String name, String category, String quantity) {
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ID", 0);
        contentValues.put("Name", name);
        contentValues.put("Category", category);
        contentValues.put("Quantity", quantity);
        long res = db.insert("inventory", null, contentValues);
        db.close();
        return res;
    }
}





